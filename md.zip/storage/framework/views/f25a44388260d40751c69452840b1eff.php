
<?php $__env->startSection('styles'); ?>
<!-- Google Fonts: Poppins -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet" />

<style>
    html, body {
        height: 100%;
        margin: 0;
        padding: 0;
        font-family: 'Poppins', Helvetica, Arial, sans-serif;
        /* background: #111; خلفية داكنة مثلاً */
        color: #fff;
    }

    .swiper {
        width: 100%;
        height: 100vh;
        position: relative;
    }

    .swiper-slide {
        position: relative;
        display: flex;
        justify-content: center;
        align-items: center;
        background: #222;
        overflow: hidden;
    }

    .swiper-slide img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        filter: brightness(0.6);
        transition: transform 0.5s ease;
    }

    .swiper-slide:hover img {
        transform: scale(1.05);
    }

    /* تراكب خلفي */
    .swiper-slide > .overlay {
        position: absolute;
        inset: 0;
        background: rgba(0, 0, 0, 0.20);
        pointer-events: none;
    }

    /* النص */
    .slide-content {
        position: absolute;
        inset: 0;
        z-index: 10;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        padding: 0 20px;
        text-align: center;
    }

    .slide-content h2 {
        font-weight: 600;
        font-size: clamp(2rem, 5vw, 4rem);
        line-height: 1.1;
        text-shadow: 0 2px 8px rgba(0,0,0,0.7);
        margin: 0;
        opacity: 0;
        transform: translateY(20px);
        animation-fill-mode: forwards;
    }

    .slide-content p {
        max-width: 600px;
        margin-top: 1rem;
        font-weight: 400;
        font-size: clamp(1rem, 2.5vw, 1.5rem);
        line-height: 1.4;
        text-shadow: 0 1px 6px rgba(0,0,0,0.6);
        opacity: 0;
        transform: translateY(20px);
        animation-fill-mode: forwards;
    }

    /* أزرار */
    .slide-content .btn-group {
        margin-top: 2rem;
        display: flex;
        gap: 1rem;
        flex-wrap: wrap;
        justify-content: center;
    }

    .slide-content a {
        text-decoration: none;
        border: 2px solid #2F76B9;
        color: #2F76B9;
        padding: 0.75rem 2rem;
        border-radius: 12px;
        font-weight: 600;
        font-size: 1rem;
        background: transparent;
        transition: all 0.3s ease;
    }

    .slide-content a:hover {
        background-color: #2F76B9;
        color: #fff;
        box-shadow: 0 4px 12px rgba(47, 118, 185, 0.6);
    }

    /* الأنيميشن عند ظهور السلايد */
    .animate-fade-in {
        animation: fadeInUp 0.7s ease forwards;
    }

    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    /* تموج ripple */
    .ripple-effect {
        position: absolute;
        top: 50%;
        left: 50%;
        width: 120px;
        height: 120px;
        background: radial-gradient(circle, rgba(47, 118, 185, 0.4) 10%, transparent 70%);
        border-radius: 50%;
        pointer-events: none;
        transform: translate(-50%, -50%) scale(0);
        animation: ripple 0.8s ease-out forwards;
        z-index: 20;
    }

    @keyframes ripple {
        to {
            transform: translate(-50%, -50%) scale(4);
            opacity: 0;
        }
    }

    /* Swiper pagination & nav */
    .swiper-pagination-bullet {
        background: #2F76B9 !important;
        opacity: 0.8;
    }

    .swiper-button-next,
    .swiper-button-prev {
        color: #2F76B9;
        transition: color 0.3s ease;
    }

    .swiper-button-next:hover,
    .swiper-button-prev:hover {
        color: #1c4e8a;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
   <div class="swiper mySwiper">
    <div class="swiper-wrapper">
        <?php $locale = LaravelLocalization::getCurrentLocale(); ?>
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="swiper-slide relative">
            <img src="<?php echo e(asset('storage/' . $item->image_path)); ?>" alt="" />
            <div class="overlay"></div>

            <div class="slide-content">
                <h2 class="animate-fade-in"><?php echo e($locale == 'ar' ? $item->title_ar : $item->title_en); ?></h2>
                <p class="animate-fade-in" style="animation-delay: 0.3s;">
                    <?php echo e($locale == 'ar' ? $item->description_ar : $item->description_en); ?>

                </p>
                <div class="btn-group animate-fade-in" style="animation-delay: 0.5s;">
                    <a href="#">About US</a>
                    <a href="#">Contact US</a>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="swiper-pagination"></div>
    <div class="swiper-button-next"></div>
    <div class="swiper-button-prev"></div>
</div>
   <div class="serction-2 w-full bg-[#404041] py-12">
    <div class="container mx-auto grid grid-cols-1 lg:grid-cols-2 gap-10 items-center px-4">
        
        <!-- النص -->
        <div class="order-2 md:order-1 lg:px-10" data-aos="flip-up" data-aos-delay="300">
            <h2 class="text-white text-[28px] md:text-[32px] lg:text-[36px] font-bold leading-tight mb-4">
                <span class="text-5xl md:text-6xl lg:text-7xl text-white font-black">MD </span>
                International MasterBatch & Compound
            </h2>
            <p class="text-gray-300 text-base md:text-lg leading-relaxed mb-6">
                MD international company was established from the manufacture of plastics materials in 1987 to be one of the first companies in the Middle East as a manufacturer of plastic materials in the two types of Masterbatch & Compound.
            </p>

            <div class="flex flex-wrap gap-4">
                <a href="#"
                   class="px-6 py-2 border border-white text-white hover:bg-blue-500 transition duration-300">
                    About us
                </a>
                <a href="#"
                   class="px-6 py-2 border border-white text-white hover:bg-blue-500 transition duration-300">
                    Contact us
                </a>
            </div>
        </div>

        <!-- الفيديو -->
        <div class="order-1 md:order-2" data-aos="zoom-in" data-aos-delay="300">
            <div class="w-full aspect-video rounded-xl overflow-hidden shadow-lg">
                <iframe class="w-full h-full" src="https://www.youtube.com/embed/dQw4w9WgXcQ" title="YouTube video"
                    frameborder="0" allowfullscreen></iframe>
            </div>
        </div>
    </div>
</div>

<!-- قسم المشاريع -->
<div class="our-project py-12 bg-white">
    <div class="container mx-auto px-4">
        <div class="flex items-center justify-center">
            <!-- خط يسار -->
            <div class="hidden md:block flex-grow border-t border-gray-300 mr-4"></div>

            <!-- العنوان -->
            <div class="text-center">
                <span class="text-[#438BCF] font-bold text-sm md:text-base uppercase tracking-widest block mb-2">
                    AL-GAMMAL CONTRACTING
                </span>
                <h3 class="text-black text-2xl md:text-4xl font-bold">
                    DIVERSITY
                </h3>
            </div>

            <!-- خط يمين -->
            <div class="hidden md:block flex-grow border-t border-gray-300 ml-4"></div>
        </div>
    </div>
</div>


    
    <div class="container mx-auto md:max-w-[1350px] px-4 py-10">
    <!-- شبكة المنتجات -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 lg:grid-rows-6 gap-4">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="<?php echo e($gridClasses[$index]['wrapper'] ?? 'lg:col-span-3 lg:row-span-3'); ?> " data-aos="flip-up" data-aos-delay="400">
                <a href="<?php echo e(route('product.show', $product->slug)); ?>">
                    <div class="relative bg-black text-white rounded-3xl overflow-hidden border-2 shadow-xl transition-transform duration-500 hover:scale-105">
                        <img src="<?php echo e(asset('storage/products/' . $product->image)); ?>"
                             class="w-full h-64 object-cover opacity-80 <?php echo e($gridClasses[$index]['image_height'] ?? ''); ?>" />

                        <div class="absolute inset-0 p-4 flex flex-col justify-center items-start">
                            <h2 class="font-semibold text-lg md:text-base lg:text-sm text-white">
                                <?php echo e($product->name); ?>

                            </h2>
                            <p class="text-sm md:text-xs text-white mt-2">
                                <?php echo e(Str::limit($product->description, 150)); ?>

                            </p>
                        </div>
                    </div>
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

    

    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    var swiper = new Swiper(".mySwiper", {
        effect: 'fade',
        autoplay: {
            delay: 4000,
            disableOnInteraction: false,
        },
        loop: true,
        pagination: {
            el: ".swiper-pagination",
            clickable: true,
        },
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
        fadeEffect: {
            crossFade: true,
        },
        on: {
            slideChangeTransitionStart: function () {
                // إزالة الأنيميشن من العناوين القديمة
                document.querySelectorAll('.slide-content h2, .slide-content p, .btn-group').forEach(el => {
                    el.style.opacity = 0;
                    el.style.transform = 'translateY(20px)';
                    el.style.animation = 'none';
                });

                // إضافة الأنيميشن للعناصر في السلايد الحالي
                let activeSlide = this.slides[this.activeIndex];
                if (!activeSlide) return;

                const heading = activeSlide.querySelector('h2');
                const paragraph = activeSlide.querySelector('p');
                const btnGroup = activeSlide.querySelector('.btn-group');

                if (heading) {
                    heading.style.animation = 'fadeInUp 0.7s ease forwards';
                    heading.style.animationDelay = '0s';
                }
                if (paragraph) {
                    paragraph.style.animation = 'fadeInUp 0.7s ease forwards';
                    paragraph.style.animationDelay = '0.3s';
                }
                if (btnGroup) {
                    btnGroup.style.animation = 'fadeInUp 0.7s ease forwards';
                    btnGroup.style.animationDelay = '0.5s';
                }
            },

            slideChangeTransitionEnd: function () {
                // تأثير ripple عند تغيير السلايد
                let activeSlide = this.slides[this.activeIndex];
                const ripple = document.createElement('div');
                ripple.classList.add('ripple-effect');
                activeSlide.appendChild(ripple);

                ripple.addEventListener('animationend', () => ripple.remove());
            }
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\md\resources\views/Home/index.blade.php ENDPATH**/ ?>